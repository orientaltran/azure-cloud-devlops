/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9150069229949941, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8473053892215568, 500, 1500, "Post an user"], "isController": false}, {"data": [0.8856304985337243, 500, 1500, "Post a cover photo"], "isController": false}, {"data": [0.93646408839779, 500, 1500, "Get all activities"], "isController": false}, {"data": [0.9337016574585635, 500, 1500, "Get an activity"], "isController": false}, {"data": [0.9579710144927536, 500, 1500, "Delete a book"], "isController": false}, {"data": [0.9432835820895522, 500, 1500, "Get an user"], "isController": false}, {"data": [0.949438202247191, 500, 1500, "Get all authors"], "isController": false}, {"data": [0.9480337078651685, 500, 1500, "Get an author"], "isController": false}, {"data": [0.9602272727272727, 500, 1500, "Delete an author"], "isController": false}, {"data": [0.9508928571428571, 500, 1500, "Get all users"], "isController": false}, {"data": [0.9546783625730995, 500, 1500, "Get all cover photo for book"], "isController": false}, {"data": [0.9427710843373494, 500, 1500, "Delete an user"], "isController": false}, {"data": [0.9057142857142857, 500, 1500, "Get a book"], "isController": false}, {"data": [0.8861671469740634, 500, 1500, "Put a book"], "isController": false}, {"data": [0.9327731092436975, 500, 1500, "Delete an activity"], "isController": false}, {"data": [0.9478260869565217, 500, 1500, "Get all cover photos"], "isController": false}, {"data": [0.948377581120944, 500, 1500, "Delete a cover photo"], "isController": false}, {"data": [0.8904494382022472, 500, 1500, "Post an author"], "isController": false}, {"data": [0.8941504178272981, 500, 1500, "Put an activity"], "isController": false}, {"data": [0.9508426966292135, 500, 1500, "Get all author for book"], "isController": false}, {"data": [0.934402332361516, 500, 1500, "Get a cover photo"], "isController": false}, {"data": [0.8963963963963963, 500, 1500, "Put an user"], "isController": false}, {"data": [0.8923512747875354, 500, 1500, "Put an author"], "isController": false}, {"data": [0.9057971014492754, 500, 1500, "Post a book"], "isController": false}, {"data": [0.8812316715542522, 500, 1500, "Put a cover photo"], "isController": false}, {"data": [0.8642659279778393, 500, 1500, "Post an activity"], "isController": false}, {"data": [0.7649572649572649, 500, 1500, "Get all books"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 9389, 0, 0.0, 290.5832357013529, 2, 3891, 194.0, 623.0, 917.0, 1714.800000000003, 78.29190397171519, 2835.1337860413555, 19.77592197180691], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Post an user", 334, 0, 0.0, 377.9760479041915, 3, 1899, 294.5, 757.0, 1027.25, 1819.4499999999998, 2.8175905382947675, 0.8570923641398335, 0.8240737250191917], "isController": false}, {"data": ["Post a cover photo", 341, 0, 0.0, 331.55425219941327, 3, 2162, 206.0, 737.8000000000001, 992.8999999999997, 1718.9199999999987, 2.875962519714259, 1.052138219623173, 1.042262970295777], "isController": false}, {"data": ["Get all activities", 362, 0, 0.0, 273.71270718232034, 20, 1828, 203.0, 514.4, 664.8499999999999, 1684.9700000000007, 3.0358939953035895, 9.210743563401543, 0.6107364873364644], "isController": false}, {"data": ["Get an activity", 362, 0, 0.0, 263.9917127071824, 4, 1769, 181.5, 537.0, 823.0, 1648.5800000000002, 3.036046765184427, 1.0425108138198835, 0.6169918500595468], "isController": false}, {"data": ["Delete a book", 345, 0, 0.0, 207.93043478260876, 3, 1777, 147.0, 434.80000000000007, 644.299999999999, 1474.7800000000022, 2.9258364075817327, 0.6028823066403766, 0.6431655615273714], "isController": false}, {"data": ["Get an user", 335, 0, 0.0, 240.69552238805957, 3, 2569, 165.0, 506.40000000000003, 667.0, 1721.719999999996, 2.826455624646693, 0.8564809810121242, 0.5605946472414637], "isController": false}, {"data": ["Get all authors", 356, 0, 0.0, 228.66853932584257, 8, 1661, 161.0, 469.8000000000004, 593.5999999999999, 1475.7100000000007, 3.0109527635640885, 137.07518065187972, 0.5968978623081151], "isController": false}, {"data": ["Get an author", 356, 0, 0.0, 239.32865168539314, 4, 1823, 163.5, 432.7000000000001, 799.8999999999999, 1692.2900000000006, 3.0242021118445086, 0.9754674478834833, 0.6057214415717356], "isController": false}, {"data": ["Delete an author", 352, 0, 0.0, 197.80965909090907, 3, 2174, 136.5, 361.49999999999983, 662.0, 1729.4999999999986, 2.9609939518333768, 0.6101266834344165, 0.6566797305453445], "isController": false}, {"data": ["Get all users", 336, 0, 0.0, 240.4761904761906, 3, 2404, 164.5, 474.0, 783.6499999999997, 1681.2999999999995, 2.8387249393813945, 2.17339878171388, 0.5572106570465433], "isController": false}, {"data": ["Get all cover photo for book", 342, 0, 0.0, 220.47076023391796, 3, 2449, 161.0, 449.19999999999993, 620.1499999999994, 1361.4499999999994, 2.8845667245829185, 1.0095588173276429, 0.5805655084470572], "isController": false}, {"data": ["Delete an user", 332, 0, 0.0, 247.81927710843388, 3, 2178, 157.5, 466.49999999999994, 939.7999999999997, 2010.67, 2.8210182856365984, 0.581284041278635, 0.620126481140813], "isController": false}, {"data": ["Get a book", 350, 0, 0.0, 371.1999999999998, 82, 2607, 283.0, 596.7, 966.4999999999997, 2202.5000000000005, 2.9489329075635915, 13.597987116322765, 0.584890892115396], "isController": false}, {"data": ["Put a book", 347, 0, 0.0, 352.54755043227664, 8, 3006, 263.0, 726.3999999999999, 1016.3999999999995, 2028.12, 2.9243708810194002, 0.7482277058858231, 1.0997994235534057], "isController": false}, {"data": ["Delete an activity", 357, 0, 0.0, 242.1904761904762, 2, 2454, 157.0, 522.7999999999995, 1013.2999999999995, 1868.1000000000024, 2.9993194821343057, 0.6180238386038461, 0.6739624334184681], "isController": false}, {"data": ["Get all cover photos", 345, 0, 0.0, 241.34492753623178, 5, 1829, 169.0, 498.00000000000017, 725.5999999999998, 1461.4800000000014, 2.916092604958203, 59.05941849045719, 0.5894835636976055], "isController": false}, {"data": ["Delete a cover photo", 339, 0, 0.0, 240.4306784660767, 3, 2563, 159.0, 467.0, 771.0, 1682.4000000000053, 2.8595046899250964, 0.5892143452873001, 0.6453358810901545], "isController": false}, {"data": ["Post an author", 356, 0, 0.0, 329.0674157303369, 3, 1898, 260.5, 747.3, 882.7499999999999, 1512.0400000000002, 2.9938105489773954, 0.9218427413759754, 0.8838353808909108], "isController": false}, {"data": ["Put an activity", 359, 0, 0.0, 314.5487465181057, 4, 2037, 238.0, 700.0, 945.0, 1676.3999999999992, 3.015666344659582, 0.9894991127304801, 0.9780062817631988], "isController": false}, {"data": ["Get all author for book", 356, 0, 0.0, 219.90449438202242, 4, 2198, 147.5, 447.90000000000003, 685.1499999999982, 1546.46, 3.031748194576918, 1.4351952512901962, 0.6131542396571399], "isController": false}, {"data": ["Get a cover photo", 343, 0, 0.0, 253.27405247813408, 3, 2002, 154.0, 542.6000000000001, 948.6000000000004, 1652.6000000000001, 2.8928791316302176, 1.0068147123567266, 0.5907129513270978], "isController": false}, {"data": ["Put an user", 333, 0, 0.0, 321.8558558558557, 4, 2269, 253.0, 628.6000000000004, 944.0000000000002, 1851.4000000000024, 2.819071484203041, 0.8575469421963361, 0.8220307685144425], "isController": false}, {"data": ["Put an author", 353, 0, 0.0, 308.60339943342774, 3, 2150, 215.0, 679.6, 1071.7, 1619.7599999999989, 2.9680826018228905, 0.9139118098997746, 0.879416980396361], "isController": false}, {"data": ["Post a book", 345, 0, 0.0, 302.2666666666666, 4, 1810, 230.0, 658.8000000000008, 941.7, 1585.9000000000008, 2.932775680914006, 0.750378152733857, 1.1399289306632323], "isController": false}, {"data": ["Put a cover photo", 341, 0, 0.0, 325.44868035190603, 3, 2153, 244.0, 713.2, 948.8, 1700.5399999999997, 2.8891694273344237, 1.05696981675803, 1.03885789904005], "isController": false}, {"data": ["Post an activity", 361, 0, 0.0, 378.3213296398891, 3, 3891, 272.0, 822.8000000000002, 1008.5999999999997, 2045.58, 3.0275837198185127, 0.9934095278730596, 0.9786264042411332], "isController": false}, {"data": ["Get all books", 351, 0, 0.0, 571.4700854700856, 116, 3109, 408.0, 1279.6000000000013, 1733.599999999999, 2780.880000000003, 2.9618503548313604, 2629.7709305937624, 0.58137882941514], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 9389, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
